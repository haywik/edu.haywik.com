print("main.py")

import time
import sc
import sys
import schoolwork.work1 as work1
import newuser as acccreate
import maingui
import database.adminpas as adpas

adpas = adpas.adminpass

global access2
global access
global AC
global delay_time
global space_gap



delay_time = 0.25
space_gap = " "

time.sleep(delay_time)

def delay():
    time.sleep(delay_time)

def space():
    print(space)

def spay():
    print(space_gap)
    time.sleep(delay_time)




def BackgroundVerif():

    access = sc.AC

    if access == 1 or access2 == 1:
        pass
    else:
        print("Access denied- Code 5")

        exit()


def  Adminverifi():
    adverif = input("Type admin password:")

    if adverif == adpas:
        print("Admin access granted")
        access = 1
        access2 = 1

    else:
        print("Invalid response")
        exit()





spay()


def StartUpOptions():
    if unuser == "a":
        sc.security()


    elif unuser == "b":

        print("New account creation selected")
        adminverif = input("Program unfinished - type admin password to open :")

        Adminverifi()

        acccreate.newsign()


    elif unuser == adpas:
        print("Admin access granted")
        access = 1
        access2 = 1

    else:
        print("Error 4")






unuser = input("Login(A) \nNew account(B)  \n <:").lower()

StartUpOptions()

BackgroundVerif()

