import database.adminpas as adminfile
import database.users1 as users
from database.users1 import username, password


def newsign():
    adp = adminfile.adminpass
    nav = 0
    ac = 0

    print("New account slected")

    nav = input("Enter Admin pass for new account sign up:")

    if nav == adp:
        print("Access Granted")

        ac = 1
    else:
        print("Incorect Password")
        print("Program terminated")
        exit()

    print("Please follow the steps in creating your new account")
    newuser = input("Enter your name:").lower()

    try:
        newpas = int(input("Enter your password as digits:"))
    except:
        print("There was a letter there...   try again")
        try:
            newpas = int(input("Enter your password as digits:"))
        except:
            print("Password not accepted - program terminated")
            exit()

        # newuser
        # newpas

        username.append(newuser)
        password.append(newpas)

        with open("database.users1.py", "w") as f:
            f.write(f"username = {username}\n")
            f.write(f"password = {password}\n")


