import time
import users1
import adminpas
import os
from getpass import getpass


def clear_terminal():
    os.system('cls' if os.name=='nt' else 'printf "\033c')

def sd():
    time.sleep(0.75)
    print(" ")


def security():
    global IDinput
    bugprevent = 0
    loop = 0



    def scloop():
        global ac
        global rep
        rep = 0
        ac = 0

        admin1 = input("Hello welcome to Ash, press enter to begin:")
        if admin1 == adminpas.adminpass:
            ac = 1

        while ac == 0:

            if rep == 5:
                os.system("shutdown /1")

            # loadup

            print("\nSecurity login\n")

            sd()

            sd()

            print("\n\\\***********************************///\n")

            sd()

            # data \/'

            #
            IDamount = len(users1.username)
            #

            try:
                IDinput = int(input("Enter User ID:"))
            except:
                sd()

                print("Error- contact admin")
                time.sleep(1.4)
                ac = 0
                scloop()

            user = input("Enter username:")

            passw = getpass("Enter your (hidden) Password: ",prompt="_")

            # verifcation program

            sd()

            print("Processing")

            sd()

            #      0  <    A < 4

            try:
                if 0 <= IDinput <= IDamount:
                    # id check complete
                    a = 0

                else:
                    print("Invalid ID")
                    ac = 0

                    scloop()



            except:
                print("Error- ID -  contact admin")

            if user == users1.username[IDinput] and passw == users1.password[IDinput]:

                print("Access granted")

                ac = 1
                break


            else:
                print("Access Denied")
                ac = 0
                rep = rep + 1

    scloop()
