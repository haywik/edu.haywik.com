errors = [
    " error 0 = ",
    "error 1 = ",
    "error 2= ",
    "error 3 =",
    "error 4 = start up options error",
    "error 5 = background verif"



]