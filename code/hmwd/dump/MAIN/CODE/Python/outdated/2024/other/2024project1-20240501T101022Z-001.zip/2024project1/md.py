import time
import keyboard

def stopwatch():
    secs = 0
    mins = 0
    hours = 0


    print("Stopwatch")
    input("Press enter to start")


    try:
        while True:
            secs = secs + 1
            time.sleep(1)
            print("\r",secs,end=" ",flush=True)

            if  keyboard.is_pressed('space'):
                break


    except:
        pass
