'''
import  schoolwork.gui1 as g1

input("Currenty unfished press enter to start:")

g1.startergui()

'''

