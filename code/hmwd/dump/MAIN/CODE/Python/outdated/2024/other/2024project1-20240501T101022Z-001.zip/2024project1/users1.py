
username = ["hay", "harry", "oscar", "joel"]

password = ["1012", "2010", "1517", "2945"]

